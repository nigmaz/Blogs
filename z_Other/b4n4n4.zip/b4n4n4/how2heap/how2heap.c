#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

char *tmp[10];
char* store[10];
int storeSize[10];
int heapSize[10];


int readint() {
	char ret[10];
	read(0, ret, 8);
	return atoi(ret);
}

void readStr(char *buf, int len) {
	read(0, buf, len);
}

void setup() {
	setbuf(stdin, 0);
	setbuf(stdout, 0);
	setbuf(stderr, 0);
	for (int i = 0; i < 8; ++i)
		tmp[i] = malloc(8);
	for (int i = 0; i < 7; ++i)
		free(tmp[i]);
}

void menu() {
	printf("Option: \n");
	printf("1. Create heap\n");
	printf("2. Show heap\n");
	printf("3. Edit heap\n");
	printf("4. Delete heap\n");
	printf("5. Quit\n");
}

int createHeap() {
	printf("Index: ");
	int id = readint();
	if (id >= 0xa) {
		exit(0);
	}
	printf("Size: ");
	storeSize[id] = readint();
	store[id] = malloc(storeSize[id]);
	printf("Data: ");
	readStr(store[id], storeSize[id]);
}

void editHeap() {
	printf("Index: ");
	int id = readint();
	if (id >= 0xa) {
		exit(0);
	}
	int size = storeSize[id];
	printf("Data: ");
	read(0, store[id], size);
}

void deleteHeap() {
	printf("Index: ");
	int id = readint();
	if (id >= 0xa) {
		exit(0);
	}
	free(store[id]);
}

void showHeap() {
	printf("Index: ");
	int id = readint();
	printf("Data: %s\n", store[id]);
}



void goodbye() {
	printf("See you again!\n");
	exit(0);
}


void greeting() {
	printf("Welcome to PTIT CTF\n");
	printf("Here's an simple heap challenge\n------------\n");
}

int main() {
	setup();
	greeting();
	while (1) {
		menu();
		printf("Option:\n> ");
		int option = readint();
		switch (option) {
			case 1:
				createHeap();
				break;
			case 2:
				showHeap();
				break;
			case 3:
				editHeap();
				break;
			case 4:
				deleteHeap();
				break;
			default:
				goodbye();
		}
	}
	return 0;
}
