#!/usr/bin/env python3 

from pwn import *

elf = ELF('./vuln')
libc = ELF('./libc.2.23.so')
p = elf.process()
context.log_level = 'DEBUG'
gdb.attach(p, '''
	b *0x400b0f
''')



p.interactive()
