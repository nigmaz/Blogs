#include<stdio.h>
#include<stdlib.h>

unsigned int setup()
{
  setvbuf(stdin, 0LL, 2, 0LL);
  setvbuf(stdout, 0LL, 2, 0LL);
  setvbuf(stderr, 0LL, 2, 0LL);
  return alarm(0x3Cu);
}

int __cdecl main(int argc, const char **argv, const char **envp)
{
  int v4; // [rsp+0h] [rbp-A0h] BYREF
  unsigned int i; // [rsp+4h] [rbp-9Ch]
  __int64 v6; // [rsp+8h] [rbp-98h]
  __int64 v7[16]; // [rsp+10h] [rbp-90h] BYREF

  _QWORD v8[2]; // [rsp+90h] [rbp-10h] BYREF
  v8[1] = __readfsqword(0x28u);

  memset(v7, 0, sizeof(v7));
  v4 = 0;
  v6 = 0LL;
  setup(v8, argv, v7);
  while ( v4 <= 0 )
  {
    printf("Enter n: ");
    __isoc99_scanf("%d", &v4);
  }
  for ( i = 0; (int)i < v4; ++i )
  {
    printf("Enter arr[%d]: ", i);
    __isoc99_scanf("%lu", &v7[i]);
    v6 += v7[i];
  }
  printf("%lu\n", v6);
  return 0;
}

// 0x49c2f81d17c61600
// 
