#include <stdio.h>
#include <stdlib.h>

// .bss:0804A048 byte_804A048    db ?                    ; DATA XREF: sub_80485E0↑r
// .bss:0804A048                                         ; sub_80485E0+14↑w
// .bss:0804A049                 align 4
// .bss:0804A04C count   dd ?                    ; DATA XREF: addNote+12↑r
// .bss:0804A04C                                         ; addNote+15B↑r ...
// .bss:0804A050 ; void *ptr
// .bss:0804A050 ptr             dd ?                    ; DATA XREF: addNote+40↑r
// .bss:0804A050                                         ; addNote+61↑w ...
// .bss:0804A054                 db    ? ;
// .bss:0804A055                 db    ? ;
// .bss:0804A056                 db    ? ;
// .bss:0804A057                 db    ? ;
// .bss:0804A058                 db    ? ;
// .bss:0804A059                 db    ? ;
// .bss:0804A05A                 db    ? ;
// .bss:0804A05B                 db    ? ;
// .bss:0804A05C                 db    ? ;
// .bss:0804A05D                 db    ? ;
// .bss:0804A05E                 db    ? ;
// .bss:0804A05F                 db    ? ;
// .bss:0804A060                 db    ? ;
// .bss:0804A061                 db    ? ;
// .bss:0804A062                 db    ? ;
// .bss:0804A063                 db    ? ;
// .bss:0804A063 _bss            ends

int count;
typedef struct note
{
    void (*pprint)(struct *note);
    char *content;
} NOTE;

int menu()  //0x08048956
{
    puts("----------------------");
    puts("       HackNote       ");
    puts("----------------------");
    puts(" 1. Add note          ");
    puts(" 2. Delete note       ");
    puts(" 3. Print note        ");
    puts(" 4. Exit              ");
    puts("----------------------");
    return printf("Your choice :");
}

int __cdecl print_note(NOTE *note) // 0x0804862b
{
    return puts(note->content);
}

unsigned int deleteNote()   //  0x080487d4
{
    int v1;      // [esp+4h] [ebp-14h]
    char buf[4]; // [esp+8h] [ebp-10h] BYREF

    unsigned int v3; // [esp+Ch] [ebp-Ch]
    v3 = __readgsdword(0x14u);

    printf("Index :");
    read(0, buf, 4u);
    v1 = atoi(buf);
    if (v1 < 0 || v1 >= count)
    {
        puts("Out of bound!");
        _exit(0);
    }
    if (note_list[i])
    {
        free(notes_list[i]->content);
        free(notes_list[i]);
        puts("Success");
    }
    return __readgsdword(0x14u) ^ v3;
}

unsigned int printNote()    //  0x080488a5
{
    int v1;      // [esp+4h] [ebp-14h]
    char buf[4]; // [esp+8h] [ebp-10h] BYREF

    unsigned int v3; // [esp+Ch] [ebp-Ch]
    v3 = __readgsdword(0x14u);

    printf("Index :");
    read(0, buf, 4u);
    v1 = atoi(buf);
    if (v1 < 0 || v1 >= count)
    {
        puts("Out of bound!");
        _exit(0);
    }
    if (notes_list[v1])
        (*(void(__cdecl **)(NOTE *))notes_list[v1]->pprint)(notes_list[v1]);
    return __readgsdword(0x14u) ^ v3;
}

unsigned int addNote() // 0x08048646
{
    NOTE *note;
    int i;       // [esp+Ch] [ebp-1Ch]
    int size;    // [esp+10h] [ebp-18h]
    char buf[8]; // [esp+14h] [ebp-14h] BYREF

    unsigned int v5; // [esp+1Ch] [ebp-Ch]
    v5 = __readgsdword(0x14u);

    if (count <= 5)
    {
        for (i = 0; i <= 4; ++i)
        {
            if (!notes_list[i])
            {
                notes_list[i] = (NOTE *)malloc(8u);
                if (!notes_list[i])
                {
                    puts("Alloca Error");
                    exit(-1);
                }
                notes_list[i]->pprint = print_note;
                printf("Note size :");
                read(0, buf, 8u);
                size = atoi(buf);
                note = notes_list[i];
                note->content = (char *)malloc(size);
                if (!notes_list[i]->content)
                {
                    puts("Alloca Error");
                    exit(-1);
                }
                printf("Content :");
                read(0, notes_list[i]->content, size);
                puts("Success !");
                ++count;
                return __readgsdword(0x14u) ^ v5;
            }
        }
    }
    else
    {
        puts("Full");
    }
    return __readgsdword(0x14u) ^ v5;
}

void __cdecl __noreturn main()  //  0x080489ef - 100i
{
    int v0;          // eax
    char buf[4];     // [esp+8h] [ebp-10h] BYREF
    unsigned int v2; // [esp+Ch] [ebp-Ch]

    v2 = __readgsdword(0x14u);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stdin, 0, 2, 0);

    while (1)
    {
        while (1)
        {
            menu();
            read(0, buf, 4u);
            v0 = atoi(buf);
            if (v0 != 2)
                break;
            deleteNote();   //0x080487d4
        }
        if (v0 > 2)
        {
            if (v0 == 3)
            {
                printNote();    //0x080488a5
            }
            else
            {
                if (v0 == 4)
                    exit(0);
            LABEL_13:
                puts("Invalid choice");
            }
        }
        else
        {
            if (v0 != 1)
                goto LABEL_13;
            addNote();  //0x08048646
        }
    }
}



